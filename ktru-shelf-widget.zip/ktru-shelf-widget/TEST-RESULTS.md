Reference catalog rows: 19118
Canonical excluded: 0
Stored assignments differing from allocator: 0
Sampled shelf position checks passed: 464
Database SHA-256 before/after: d93c97784986d4ee678252f2a0936f85f8ed3c2886c333390f415f07c5edc290
Barcode 4157: 1A, position 1 of 26
Windows UI/hardware: not run on this Mac.
