# KTRU Shelf Locator — Windows meeting prototype

Small, always-on-top native Windows widget in black and marigold, using Courier New. Barcode + Enter gives the catalog's final_shelf and its one-based canonical position. No npm install, server, browser, or administrator account needed.

## Launch on the station PC (Windows 10/11, x64)

1. Download/extract this entire project ZIP to a new folder. Do not extract over the sorter or data folders.
2. If Node 22.13+ is already installed, skip setup. Otherwise double-click **Setup-Portable-Node.cmd** once (internet required). This downloads checksum-verified Node 24.9.0 x64 from nodejs.org into this project's runtime folder. It changes no system settings. Node redistribution/license information: https://github.com/nodejs/node/blob/v24.9.0/LICENSE
3. Double-click **Launch.cmd**. Click **Choose DB** and select the station's existing **masterAlbums.db**. The reference sorter defaults to `../data/masterAlbums.db`, not necessarily the database in its repository. Choose the same file the running station tools use. A KTRU_DB environment variable also works.
4. Click the scan box. Scan with a keyboard-style USB scanner configured to send Enter (CR/CRLF), or type a barcode and press Enter. Leading zeroes are preserved. The field clears and refocuses after each result.
5. The minimal window shows shelf, position, and album. Drag its title bar to move; minimize/close normally. The window stays on top. Click the scan box again after using another app. The DB button changes the catalog; hover over its filename to see the full path.

No Node installed and no internet on the station? On another Windows x64 PC run setup, then transfer the whole folder including runtime/node.exe by USB. Do not commit the runtime to GitHub. Windows policy may block PowerShell; use your station administrator's approved launch process if so. These launchers apply ExecutionPolicy Bypass only to their own process.

## Meeting demo without station data

Double-click **Launch-Demo.cmd** after Node setup. This explicitly selects the included synthetic demo.db. Try `001234` (12C, 1 of 2), `005678` (12C, 2 of 2), `009999` (unassigned), or `000000` (unknown). The title-area DB label reads demo.db. Demo data are invented and are never installed over a catalog.

## Rules and database safety

- The database opens with Node SQLite `readOnly: true`, extension loading disabled, and `query_only=ON`. Only schema inspection and SELECT queries are used. Each scan opens a fresh consistent read transaction and closes it. No migrations, backup/restore, assignments, sorting confirmations, or DB replacement occur. Missing paths fail instead of creating files. SQLite may use its normal WAL shared-memory sidecars while coordinating a live database; the catalog is never opened for writing.
- `final_shelf` is authoritative. It is a destination, not a claim that the CD is physically there. `new_shelf_label`, working pile order, and sorted flags never override the displayed destination.
- The inspected schema has no stored final position. Position is derived among ALL rows assigned to the exact stored final_shelf, including unbarcoded CDs, using the reference allocator's `ordered_albums`. Order is primary genre rank, secondary genre rank (blank first), trimmed NFC lowercased artist_sort, similarly normalized title, then numeric ID. This is desired catalog order, not verified physical order or a count of CDs currently on the shelf.
- The canonical allocator and capacity configuration are preserved unchanged under vendor/. Its computed shelf assignments are discarded. No allocation is saved. Unresolved sort metadata anywhere on a shelf suppresses the position; duplicate IDs fail safely. Unknown and duplicate barcodes, missing destinations, and unavailable DBs get explicit messages.
- No live database is bundled. Do not copy this project's demo.db onto a station database path. Prefer choosing the live database directly. For an offline catalog, obtain a consistent SQLite backup from the station's existing backup process; copying only a live WAL-mode .db can miss committed changes.
- No scan history is persisted. Select the DB again after reopening, or set KTRU_DB. Reads are local; setup is the only network operation.

## Source reference

https://github.com/matthewlbitz/final-sorter at commit **94ac916fbf7ec25f040d9a8f803c3630f4a6b8c1**. Inspected `rainbow_albums`, `server.js`, `workflow.js`, `shelf-allocation.js`, and `reallocate-shelves.js`. The sorter lookup uses exact trimmed barcode strings; this widget additionally rejects ambiguous duplicate matches. Vendor files originate in that repository. No license was present in the inspected repository; confirm redistribution terms before sharing beyond your project.

## Checks and development

Run `node --test test/*.test.cjs` (or `npm test`, no install required). CLI: `node --no-warnings lookup.cjs "C:\path\masterAlbums.db" 4157`.

Verified here on macOS / Node 22.23.3: fixture checks for canonical order, unbarcoded neighbors, exact leading-zero matching, SQL-like barcode input, unknown/duplicate/unassigned codes, missing-path noncreation, unresolved metadata, actual read-only write rejection, unchanged database hash, and visibility of committed WAL updates. Real reference catalog checked separately; see TEST-RESULTS.md.

Windows WPF interaction and actual scanner hardware have not been executed here. A GitHub Actions Windows check is included for Node tests and WPF window construction. Before the meeting: launch demo, scan the three demo codes, check that the window stays on top over another app, then choose the station catalog and scan a known CD. Native WPF is used so always-on-top is an actual window property. The brief synchronous read can pause the window while a busy database times out (1.5 seconds).

## Put on GitHub

Create an empty repository, upload the contents of this folder including hidden `.github` and `.gitignore`, or commit/push it with Git. Keep real databases and runtime out of Git; .gitignore allows only the synthetic demo.db. No changes to final-sorter are required.

## Interactive Mac preview

Run `node --no-warnings preview.cjs` from this folder, then open the localhost URL it prints. It uses demo.db by default. To inspect a real catalog, pass its path: `node --no-warnings preview.cjs "/path/masterAlbums.db"`. Stop with Ctrl+C. This browser preview uses the same lookup engine, but has no always-on-top window.

Unknown barcodes show a compact message and keep the input ready. If the scanner fails to read the label, type the barcode manually and press Enter. There is no artist/title search or automatic assignment fallback.

Found results use the KTRU locator format `Shelf [ shelf_label.position ]`, for example `Shelf [ 12C.1 ]`. An unresolved position displays `?` rather than inventing a number.
