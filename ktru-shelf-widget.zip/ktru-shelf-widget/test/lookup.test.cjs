const {test}=require('node:test');
const assert=require('node:assert/strict');
const {DatabaseSync}=require('node:sqlite');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto');
const {lookup}=require('../lookup.cjs');
const hash=f=>crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
test('read-only lookup, canonical order, exact strings, unknowns and ambiguity',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'ktru-'));const file=path.join(dir,'catalog.db');
 try {
 const db=new DatabaseSync(file);
 db.exec('CREATE TABLE rainbow_albums(id INTEGER,barcode TEXT,artist TEXT,artist_sort TEXT,title TEXT,primary_genre TEXT,secondary_genre TEXT,final_shelf TEXT)');
 const insert=db.prepare('INSERT INTO rainbow_albums VALUES(?,?,?,?,?,?,?,?)');
 insert.run(1,'0012','The Zebra','zebra','Last','Rock','','1A');
 insert.run(2,null,'Alpha','alpha','First','Rock','','1A');
 insert.run(3,'3','Jazz','zzz','Jazz','Jazz','','1A');
 insert.run(4,'DUP','A','a','A','Rock','','2A');insert.run(5,'DUP','B','b','B','Rock','','2A');
 insert.run(6,'6','No shelf','n','N','Rock','',null);db.close();
 const before=hash(file);
 assert.equal(lookup(file,' 0012\r\n').position,3);
 assert.equal(lookup(file,'0012').previous.id,2);
 assert.equal(lookup(file,'12').status,'unknown');
 assert.equal(lookup(file,"' OR 1=1 --").status,'unknown');
 assert.equal(lookup(file,'DUP').status,'duplicate');assert.equal(lookup(file,'6').status,'unassigned');
 assert.equal(lookup(file,'').status,'invalid');assert.equal(hash(file),before);
 const ro=new DatabaseSync(file,{readOnly:true});assert.throws(()=>ro.exec('DELETE FROM rainbow_albums'),/readonly/i);ro.close();
 const writer=new DatabaseSync(file);writer.exec('PRAGMA journal_mode=WAL');
 writer.prepare('UPDATE rainbow_albums SET final_shelf=? WHERE id=1').run('3A');
 assert.equal(lookup(file,'0012').shelf,'3A');writer.close();
 const edit=new DatabaseSync(file);edit.prepare('UPDATE rainbow_albums SET artist_sort=? WHERE id=2').run('');edit.close();
 assert.equal(lookup(file,'3').position,null);
 assert.throws(()=>lookup(path.join(dir,'missing.db'),'1'));
 assert.equal(fs.existsSync(path.join(dir,'missing.db')),false);
 }finally{fs.rmSync(dir,{recursive:true,force:true})}
});
