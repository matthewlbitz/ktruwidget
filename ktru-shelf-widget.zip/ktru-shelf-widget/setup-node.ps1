$ErrorActionPreference='Stop'
[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
$target=Join-Path $PSScriptRoot 'runtime'
New-Item -ItemType Directory -Force $target | Out-Null
$temp=Join-Path $target 'node-download.tmp'
try {
 Invoke-WebRequest -UseBasicParsing 'https://nodejs.org/download/release/v24.9.0/win-x64/node.exe' -OutFile $temp
 $hash=(Get-FileHash $temp -Algorithm SHA256).Hash.ToLowerInvariant()
 if($hash -ne '5f364598aa3017130b22908ff7c3db0fd05bd42d39fd65b79fd6bd3f73c73da6'){throw 'Node download checksum mismatch.'}
 Move-Item -Force $temp (Join-Path $target 'node.exe')
 Write-Host 'Portable Node ready. Double-click Launch.cmd. No administrator access required.'
} finally {if(Test-Path $temp){Remove-Item $temp}}
