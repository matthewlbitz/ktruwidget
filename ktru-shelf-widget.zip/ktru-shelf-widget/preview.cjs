const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
const {lookup}=require('./lookup.cjs');
const database=path.resolve(process.argv[2]||path.join(__dirname,'demo.db'));
const server=http.createServer((req,res)=>{
 const url=new URL(req.url,'http://localhost');
 res.setHeader('Cache-Control','no-store');
 res.setHeader('X-Content-Type-Options','nosniff');
 if(req.method!=='GET'){res.writeHead(405);return res.end();}
 if(url.pathname==='/api/lookup'){
  res.setHeader('Content-Type','application/json');
  try {return res.end(JSON.stringify(lookup(database,url.searchParams.get('barcode'))));}
  catch(e){res.writeHead(500);return res.end(JSON.stringify({status:'error',message:e.message}));}
 }
 if(url.pathname!=='/'){res.writeHead(404);return res.end();}
 res.setHeader('Content-Type','text/html; charset=utf-8');
 res.end(fs.readFileSync(path.join(__dirname,'preview.html')));
});
server.listen(0,'127.0.0.1',()=>console.log('KTRU preview: http://127.0.0.1:'+server.address().port+' — database: '+database));
