@echo off
set "KTRU_DB=%~dp0demo.db"
call "%~dp0Launch.cmd"
