@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup-node.ps1"
pause
