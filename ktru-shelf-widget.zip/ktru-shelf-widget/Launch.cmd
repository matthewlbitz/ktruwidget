@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0widget.ps1"
if errorlevel 1 pause
